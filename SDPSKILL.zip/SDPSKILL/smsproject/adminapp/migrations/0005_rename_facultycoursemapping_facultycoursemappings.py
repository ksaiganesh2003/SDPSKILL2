
from django.db import migrations

class Migration(migrations.Migration):
    dependencies = [
    ('adminapp', '0005_rename_facultycoursemapping_facultycoursemappings'),
    # Add any other dependencies here if needed
]
