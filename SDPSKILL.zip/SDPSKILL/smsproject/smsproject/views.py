from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import render

def demofunction(request):
    return HttpResponse("PFSD SDP Project")
def demofunction1(request):
    return HttpResponse("KL UNIVERSITY")
def demofunction2(request):
    return HttpResponse("Student Management System")
def homefunction(request):
    return render(request,"index.html")
def aboutfunction(request):
    return render(request,"about.html")
def loginfunction(request):
    return render(request,"logins.html")
def contactfunction(request):
    return render(request,"contact.html")
